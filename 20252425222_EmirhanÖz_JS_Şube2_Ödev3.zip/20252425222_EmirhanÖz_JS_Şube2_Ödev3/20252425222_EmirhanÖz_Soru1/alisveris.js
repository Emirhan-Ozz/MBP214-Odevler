let urunSayisi = Number(prompt("Kaç farklı ürün girmek istiyorsunuz?"));
let sepetToplami = 0;

for (let i = 1; i <= urunSayisi; i++) {
    let urunAdi = prompt(i + ". ürünün adını giriniz:");
    let fiyat = parseFloat(prompt(i + ". ürünün fiyatını giriniz:"));
    let adet = parseInt(prompt(i + ". ürünün adedini giriniz:"));

    if (fiyat < 0 || adet < 1 || isNaN(fiyat) || isNaN(adet)) {
        alert("Hatalı giriş! Fiyat 0'dan, adet 1'den küçük olamaz. Bu ürün işleme alınmadı.");
        continue;
    }

    let urunToplam = fiyat * adet;
    sepetToplami += urunToplam;

    document.writeln("Fiyatı " + fiyat + " TL olan " + urunAdi + " ürününden " + adet + " adet alındı.<br>");
    document.writeln("Toplam bedel: " + urunToplam + " TL<br><br>");
}

let indirimliToplam = sepetToplami;

if (sepetToplami >= 1000) {
    indirimliToplam = sepetToplami * 0.90;
} else if (sepetToplami >= 500) {
    indirimliToplam = sepetToplami * 0.95;
}

document.writeln("Sepet toplamı: " + sepetToplami + " TL<br>");
document.writeln("İndirimli sepet toplamı: " + indirimliToplam + " TL");