let x= 0 
let y= 1 
let sonrakiTerim;
let sayac = 1;
let sonuc = "";

while (sayac <= 20) {
    sonuc += x + (sayac < 20 ? ", " : "");
    
    sonrakiTerim = x + y;
    x = y;
    y = sonrakiTerim;
    
    sayac++;
}

console.log("Fibonacci Serisi (İlk 20 Sayı):");
console.log(sonuc);