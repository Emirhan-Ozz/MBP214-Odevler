let netflixData = [
    {
        category: "Because you watched Gupi",
        movies: [
            { title: "IF", img: "https://picsum.photos/seed/if_movie/400/225", recentlyAdded: true },
            { title: "Migration", img: "https://picsum.photos/seed/migration/400/225", recentlyAdded: false },
            { title: "Rafadan Tayfa", img: "https://picsum.photos/seed/tayfa/400/225", recentlyAdded: false },
        ]
    },
    {
        category: "Activating Hibernation Mode",
        movies: [
            { title: "Jaadugar", img: "https://picsum.photos/seed/magic/400/225", recentlyAdded: false },
            { title: "Blacklist", img: "https://picsum.photos/seed/blacklist/400/225", recentlyAdded: false },
            { title: "Peaky Blinders", img: "https://picsum.photos/seed/peaky/400/225", recentlyAdded: false },
        ]
    },
    {
        category: "30-Minute Laughs",
        movies: [
            { title: "Old Dog, New Tricks", img: "https://picsum.photos/seed/comedy1/400/225", recentlyAdded: false },
            { title: "MO", img: "https://picsum.photos/seed/comedy2/400/225", recentlyAdded: false },
            { title: "Young Sheldon", img: "https://picsum.photos/seed/sheldon/400/225", recentlyAdded: false },
        ]
    },
    {
        category: "Only on Netflix",
        movies: [
            { title: "House of Guinness", img: "https://picsum.photos/seed/guinness/400/225", recentlyAdded: false },
            { title: "Chupa", img: "https://picsum.photos/seed/chupa/400/225", recentlyAdded: false },
            { title: "The Residence", img: "https://picsum.photos/seed/residence/400/225", recentlyAdded: false },
        ]
    },
    {
        category: "Because you watched The Decameron",
        movies: [
            { title: "Crap Happens", img: "https://picsum.photos/seed/crap/400/225", recentlyAdded: true },
            { title: "Joe's College Road Trip", img: "https://picsum.photos/seed/college/400/225", recentlyAdded: true },
            { title: "PAUL", img: "https://picsum.photos/seed/paul/400/225", recentlyAdded: false },
        ]
    }
];

let mainContainer = document.getElementById('netflix-container');

for (let i = 0; i < netflixData.length; i++) {
    let row = netflixData[i];
    let categoryRow = document.createElement('div');
    categoryRow.className = 'category-row';
    let title = document.createElement('h2');
    title.className = 'category-title';
    title.innerText = row.category;
    categoryRow.appendChild(title);
    let cardsContainer = document.createElement('div');
    cardsContainer.className = 'movie-cards-container';

    for (let j = 0; j < row.movies.length; j++) {
        let movie = row.movies[j];
        let card = document.createElement('div');
        card.className = 'movie-card';
        let img = document.createElement('img');
        img.src = movie.img;
        img.alt = movie.title;
        card.appendChild(img);

        if (movie.recentlyAdded) {
            let badge = document.createElement('span');
            badge.className = 'badge';
            badge.innerText = 'Recently Added';
            card.appendChild(badge);
        }
        cardsContainer.appendChild(card);
    }
    categoryRow.appendChild(cardsContainer);
    mainContainer.appendChild(categoryRow);
}