let yasInput = prompt("Lütfen yaşınızı giriniz:");
let yas = Number(yasInput);

if (isNaN(yas)) {
    alert("Geçerli bir yaş giriniz!");
} else {
    let ogrenciMi = confirm("Öğrenci misiniz?");

    if (yas < 18) {
        alert("Reşit değilsiniz.");
    } else if (yas >= 18 && ogrenciMi) {
        alert("Hoşgeldiniz öğrenci!");
    } else {
        alert("Hoşgeldiniz!");
    }
}