let bakiye = 1000;
let islem = prompt(`
İşlem seçin:
Bakiye: 
Para Çekme: 
Para Yatırma
`);

switch (islem) {
    case "1":
        alert("Bakiyeniz: " + bakiye + " TL");
        break;

    case "2":
        let cekilecekTutar = Number(prompt("Tutar girin:"));
        if (cekilecekTutar > bakiye) {
            alert("Yetersiz bakiye!");
        } else {
            bakiye -= cekilecekTutar;
            alert("Kalan bakiye: " + bakiye + " TL");
        }
        break;

    case "3":
        let yatirilacakTutar = Number(prompt("Tutar girin:"));
        bakiye += yatirilacakTutar;
        alert("Yeni bakiye: " + bakiye + " TL");
        break;

    default:
        alert("Geçersiz işlem kodu seçtiniz.");
        break;
}